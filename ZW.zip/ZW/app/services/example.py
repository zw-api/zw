"""
@文件        :__init__.py
@说明        :测试版本1.0
@时间        :2025/07/02 21:07:45
@作者        :作文
@邮箱        :2010392910@qq.com
@版本        :1.0
"""

class Example:
    """ """
    def __init__(self):
        pass

    async def hello(self, lang, action):
        """ """
        return "hello world"

