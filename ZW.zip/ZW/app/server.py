"""
@文件        :__init__.py
@说明        :测试版本1.0
@时间        :2025/07/02 21:07:45
@作者        :作文
@邮箱        :2010392910@qq.com
@版本        :1.0
"""
import os

from simplejrpc.app import ServerApplication
from simplejrpc.response import jsonify

from app.services.example import Example
from app.schemas.example import ExampleForm
from app.middlewares.example import ExampleMiddleware


current_path = os.path.dirname(__file__)
socket_path = os.path.join(current_path, "tmp.socket")
app = ServerApplication(socket_path)
app.middleware(ExampleMiddleware())


@app.route(name="hello", form=ExampleForm)
async def hello(lang, action):
    """ """
    example = Example()
    data =  await example.hello(lang, action)
    return jsonify(data=data, msg="OK")
