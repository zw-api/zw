"""
@文件        :__init__.py
@说明        :测试版本1.0
@时间        :2025/07/02 21:07:45
@作者        :作文
@邮箱        :2010392910@qq.com
@版本        :1.0
"""

from simplejrpc.interfaces import RPCMiddleware

class ExampleMiddleware(RPCMiddleware):
    """ """

    def process_request(self, request, context):
        print("[middleware-request] ", request, context)
        return request

    def process_response(self, response, context):
        print("[middleware-response] ", response, context)
        return response